<!DOCTYPE html>
<head>
    <title> hi </title>
</head>
<body>
<?php
$name="";
$email="";
$pn="";
$pin="";
$sun="";
$city="";
$valid=true;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $q = $_REQUEST["q"];

    $name = $_POST["name"];
    $email =$_POST["email"];
    $pn =$_POST["pn"];
    $pin =$_POST["pin"];
    $sun = $_POST["sun"];
    $city = $_POST["city"];

    if(empty($name)||empty($email)||empty($pn)||empty($pin)||empty($sun)||empty($city)){
        $valid=false;
    }
    else if(preg_match ("/[0-9]/", $name))
    {
        $valid=false;
    }
    else if(!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        $valid=false;
    }
    else if(strlen($pn)!=10 && !preg_match ("/^[0-9]*$/", $pn))
    {
        $valid=false;
    }
    else if(preg_match ("/[0-9]/", $city))
    {
        $valid=false;
    }
    if($valid)
    {
       echo "SUCCESS";
        $file_open = fopen("19bce7360.csv", "a");
        $form_data = array(
     
            'name'    =>  $name,
            'email'   =>  $email,
            'phoneno' =>  $pn,
            'program' =>  $pin,
            'state'   =>  $sun,
            'city'    =>  $city,
      );
      fputcsv($file_open, $form_data);
      $name="";
      $email='';
      $pn='';
      $pin='';
      $sun='';
      $city='';
      header('location:thankyou.html');
                exit();

    }
    else{
        echo "FAILURE";
        echo "PLEASE CHECK THE ENTERED DETAILS";
    }
  } 

?>
</body>
</html>
