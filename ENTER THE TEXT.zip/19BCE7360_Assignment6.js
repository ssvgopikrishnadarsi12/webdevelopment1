let enter_text = document.getElementById('enter_text');
let li = document.getElementById('list');
let item = document.getElementsByTagName('li');
array[x] = document.getElementById("enter_text").value;
function submit() {
    var num = /^[0-9]+$/;
    if(enter_text.value== '')
    {
        alert("Enter The text");   
    }
    else if( enter_text.value.match(num))
    {
        alert("numbers are not allowed");
    }
        else
        {
        let node = document.createElement("li");
        let textnode = document.createTextNode(enter_text.value);
        node.appendChild(textnode);
       let p= li.appendChild(node);
       let btn = document.createElement("button");   
       btn.innerHTML = " x ";                  
     let b= p.appendChild(btn); 
     b.style.background="red";
     b.style.borderColor="grey";
     b.style.float="right";
     b.style.width="20px";
     btn.addEventListener("click",fd);
        }
}
function reverse() {
    var  number=document.getElementsByTagName('li').length;
          var kids = li.childNodes;  
          for(var i = number; i >= 0; i--) {  
              var c = li.removeChild(kids[i]);   
              li.appendChild(c);    
            }              
  }  
  function fd() { 
    if(item.length>0){
     if(confirm("ARE YOU SURE YOU WANT TO DELETE")) {    
     li.removeChild(li.lastElementChild);
    }      
else{
  alert("Cancelled");
   }
  }
}