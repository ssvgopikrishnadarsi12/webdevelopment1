<!DOCTYPE html>
<html>
<head>
<title>ASSIGNMENT 8</title>
<link rel="stylesheet" href="19bce7360_1.css">
</head>
<body>
<form method="POST" action="">
<label>User Name:</label><input type="text" id="inp" name="un"><span id="i">*</span><br><br>
<label>Password:</label><input type="password" id="inp" name="p"><span id="i">*</span><br><br>
<label>Confirm Password:</label><input type="password" id="inp" name="cp"><span id="i">*</span><br><br>
<label>Email Id:</label><input type="email" id="inp" name="eid"><span id="i" >*</span><br><br>
<label>Date of Birth:</label><input type="date" id="inp" name="dob"><span id="i">*</span><br><br>
<input type="submit" value="Sign-up" id="s"><br><br>
</form>
<?php
     $un="";
     $p="";
     $cp="";
     $eid="";
     $dob="";
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        include 'C:\xampp\htdocs\assignment8\2connection.php';

        $un=$_POST['un'];
        $p=$_POST['p'];
        $cp=$_POST['cp'];
        $eid=$_POST['eid'];
        $dob=$_POST['dob']; 
        if(!empty($un) && !empty($p) && !empty($cp) && !empty($eid) && !empty($dob) && (strcmp($p,$cp)==0))
                    $sql = "INSERT INTO 19bce7360_users(uname,passwords,email,dob) VALUES ('$un','$p','$eid','$dob')";
                    $result = mysqli_query($conn, $sql);
                    if($result){
                        header('location:19bce7360_success.php');
                        exit();
                    }
                    else{
                        echo "<br>CHOOSE A DIFFERENT USERNAME";
                    }
                   
            
    }
?>
</body>
</html>