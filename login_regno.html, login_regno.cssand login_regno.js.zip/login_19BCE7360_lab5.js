function button()
    {
        var g1='19BCE7360';
        var g2=document.getElementById("c1").value;
        if(g1!=g2)
        {
            document.getElementById("g").innerHTML="INVALID CAPTCHA";
            document.getElementById("c1").style.border="3px solid red";
        }
        var l=document.getElementById("b1").value.length;
        if(l<8 || l>15)
            {
            document.getElementById("g1").innerHTML="LENGTH";
            document.getElementById("b1").style.border="2px solid red";
            }
        var us='19bce7360@vitap.ac.in';
        var ps='19bce7360_321';
        var us1=document.getElementById("a1").value;
        var ps1=document.getElementById("b1").value;
        if(us!=us1)
        {            
            document.getElementById("g2").innerHTML="INVALID USERNAME";
            document.getElementById("a1").style.border="2px solid red";            
        }
        if(ps!=ps1)
        {            
            document.getElementById("g1").innerHTML="INVALID PASSWORD";
            document.getElementById("b1").style.border="2px solid red";            
        }
        if((g1==g2) && (l>=8 && l<=15) && (us==us1) && (ps==ps1))
        {
            document.getElementById("g3").innerHTML="LOGIN SUCCESFUL";
        }
    }