<!DOCTYPE html>
<html>
	<head>
		<title>Assignment-7</title>
		
	</head>
<body>
<link rel="stylesheet" href="19BCE7360.css">
<?php
$nameErr = $ErrMsg = $mailErr = $genErr = $pwdErr = $cpwdErr = $contactErr = $msgErr = "";
$name = $email = $message = $gender = $cno = $pwd = $cpwd = "";

if($_SERVER["REQUEST_METHOD"]== "POST"){
    $valid=TRUE;
    if(empty($_POST["name"])){
        $valid=FALSE;
    $nameErr="NAME IS REQUIRED";
}
else{
    $name=$_POST["name"];
    if (!preg_match ("/^[a-zA-Z]*$/", $name) ) {  
        $valid=FALSE;
        $nameErr= "Only alphabets  digits are not allowed.";  
    }
}
if(empty($_POST["email"])){
    $valid=FALSE;
    $mailErr="MAIL IS REQUIRED";
}else{
    $email=$_POST["email"];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { 
        $valid=FALSE; 
        $mailErr = "Invalid email format";  
    }  
}
if(empty($_POST['pwd'])){
    $valid=FALSE;
    $pwdErr="password must be filled";
}
else{
    $pwd=$_POST['pwd'];
    if(strlen ($pwd)< 8){
        $valid=FALSE;
        $pwdErr="password must contain atleast 8 characters.";
    }
}
if(empty($_POST['cpwd'])){
    $valid=FALSE;
    $cpwdErr="C password must be filled";
}
else{
    $cpwd=$_POST['cpwd'];
    if($cpwd != $pwd){
        $valid=FALSE;
        $cpwdErr="must match with password ,Re-enter the c password again.";
    }
}
if(empty($_POST["gender"])){
    $valid=FALSE;
    $genErr="GENDER IS REQUIRED";
}else{
    $gender=$_POST["gender"];
}
if(empty($_POST["cno"])){
    $valid=FALSE;
    $contactErr="CONTACT NO IS REQUIRED";
}else{
    $cno=$_POST["cno"];
    if (!preg_match ("/^[0-9]*$/", $cno) ) {  
        $valid=FALSE;
        $contactErr = "Only numeric value is allowed.";  
        }  
    //check mobile no length should not be less and greator than 10  
    if (strlen ($cno) != 10) {  
        $valid=FALSE;
        $contactErr = "Mobile no must contain 10 digits.";  
        }  
}

if(empty($_POST['msg'])){
    $valid=FALSE;
    $msgErr=" Message Filed is Mandatory";
}
else{
$message=$_POST["msg"];
if(strlen ($message) >=50){
    $valid=FALSE;
    $msgErr=" Message must be within 50 characters";
}
}
if($valid){
    header('location:19BCE7360_validation_success.php');
    exit();
}
}
?>

<form method="post" action= "">
<label class="lbl">Name</label>
<input type="text" name="name"><span id="err">*<?php echo $nameErr; ?></span><br>
<label class="lbl">Email</label>
<input type="text" name="email"><span id="err">*<?php echo $mailErr; ?></span><br>
<label class="lbl">Password</label>
<input type="Password" name="pwd"><span id="err">*<?php echo $pwdErr; ?></span><br>
<label class="lbl">C Password</label>
<input type="Password" name="cpwd"><span id="err">*<?php echo $cpwdErr; ?></span><br>
<label class="lbl">Gender</label>
<input type="radio" name="gender" value="Male">Male</input>
<input type="radio" name="gender" value="Female">Female</input><span id="err">
*<?php echo $genErr; ?></span><br>
<label class="lbl">Contact No</label>
<input type="text" name="cno"><span id="err">*<?php echo $contactErr; ?></span><br>
<label class="lbl">Message</label>
<textarea type="text" name="msg"></textarea><span id="err">*<?php echo $msgErr; ?></span><br>
<div class="btn">
<input type="submit" name="submit" value="Submit">
<input type="reset" name="reset" value="Reset">
  </div>
</form>
</body>