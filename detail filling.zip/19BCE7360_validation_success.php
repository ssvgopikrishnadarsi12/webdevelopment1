<?php 

echo "VALIDATION SUCCESSFUL";

?>