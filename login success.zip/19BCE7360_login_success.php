<?php 
 include('session.php');
 ?>
  <?php
  
if(isset($_SESSION['username'])){
    include 'C:\xampp\htdocs\2connection.php';
    $q = "SELECT uname from 19bce7360_users where uname ='".$_SESSION['uname']."'"; 
    $result= mysqli_query($conn, $q);  
    $row = $result -> fetch_assoc(MYSQLI_ASSOC);
    $login_session = $row['uname'];


}
?>
<!DOCTYPE html>
<html>
	<head>
		
		<style>
            * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    background-color:deepskyblue;
}
.container {
    margin-top: 5%;
    background-color: rgb(235, 135, 157);
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
div {
    display: block;
}
            #black{
                    color:black;
                    margin-left:0px;
            }
            .btn{
    margin-left:700px;
    margin-top:10px;
    
 }
                
            </style>
	</head>
<body >
    <form method="POST" action="19BCE7360_logout_success.php">
    <div class="container">
  <span id="black">Welcome...<?php echo $login_session; ?>  You Have successfully Logged In:</span>
  </div>

<button class="btn" ><a href="19BCE7360_logout_success.php "><p style=" background-color: black; color:deepskyblue;">LOGOUT</p></a></button>


</form>
</body>
</html>