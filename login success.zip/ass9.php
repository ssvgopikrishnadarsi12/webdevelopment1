<!DOCTYPE html>
<html>
<head>
    <title>my database</title>
   <link rel="stylesheet" href="19BCE7360.css">
</head>
<body>

<?php

$unErr=  $pErr= "";
$uname= $pwd=  $error= $errors= $message= "";

if($_SERVER["REQUEST_METHOD"]== "POST"){
    $valid=TRUE;
    if(empty($_POST["uname"])){
        $valid=FALSE;
    $unErr="NAME IS REQUIRED";
}
if(empty($_POST['pwd'])){
    $valid=FALSE;
    $pErr="password must be filled";
}
if($valid)
{
   
    $servername = "127.0.0.1";
    $username = "gopi";
    $password = "gopi";
    $database="db_vit_19bce7360";
    $conn = mysqli_connect($servername, $username, $password,$database);
    session_start();
    $uname = mysqli_real_escape_string($conn, $_REQUEST['uname']);
    $pwd = mysqli_real_escape_string($conn, $_REQUEST['pwd']);
   
   
      
        $sql="SELECT uname,passwords FROM 19bce7360_users WHERE uname='$uname' and   passwords = '$pwd'";
        $result = mysqli_query($conn,$sql);
        $row= $result -> fetch_array(MYSQLI_ASSOC);
        $active = $row['active'];
        $count  = mysqli_num_rows($result);
        
        if($count>=1) {
            $_SESSION['login_user'] = $uname;
                
            
            header('</location:19BCE7360>_login_success.php');
           exit();
        } else {
            
            $message = "Invalid Username or Password!";
                
        
        }
     
}
}
?>
    <div class="container">
       
    <form method="POST" action="" >
    <label class="lbl">User Name :</label>
    <input type="text" name="uname" id="w"><span id="err"> *<?php echo $unErr; ?> <?php echo $error; echo $errors; ?></span><br>
    <label class="lbl">Password :</label>
    <input type="password" name="pwd" id="w"><span id="err"> *<?php echo $pErr; ?></span><br>
    <input type="submit" value="Sign-in"><br>
<span><?php echo $message; ?></span>
</form>
</div>

</body>
</html>

